import 'package:flutter/services.dart';

/// Converts an animated GIF to an MP4 (max 512px, 24 fps, up to 30 s) using the
/// native side, so it can go through the same trim/edit pipeline as a video.
class GifToMp4 {
  static const _methodChannel = MethodChannel('de.loicezt.stickers/methods');

  /// Throws a [PlatformException] if the file isn't a valid GIF or encoding fails.
  static Future<void> convert({required String inputFile, required String outputFile}) async {
    await _methodChannel.invokeMethod('gifToMp4', {
      'inputFile': inputFile,
      'outputFile': outputFile,
    });
  }

  static bool isGif(String path) => path.toLowerCase().endsWith('.gif');
}
