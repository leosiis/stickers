package de.loicezt.stickers.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Movie
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import kotlin.math.max

/**
 * Converts an animated GIF into an H.264 MP4 so the rest of the video pipeline
 * (trim -> edit -> animated WebP) can treat it like any other video.
 *
 * GIF frames are decoded with [Movie] (which handles frame delays and disposal),
 * drawn onto a bitmap scaled to [LONGEST_SIDE], converted to YUV and fed to the
 * encoder with explicit timestamps. MP4 has no alpha channel, so transparent
 * areas end up black.
 */
@Suppress("DEPRECATION")
object GifToMp4 {
    private const val LONGEST_SIDE = 512
    private const val TIMEOUT_US = 10_000L
    private const val DEFAULT_SINGLE_FRAME_MS = 1000
    private const val MAX_DURATION_MS = 30_000

    fun convert(input: File, output: File, fps: Int = 24) {
        val movie = Movie.decodeFile(input.absolutePath)
            ?: throw IllegalArgumentException("Not a valid GIF file")
        val srcW = movie.width()
        val srcH = movie.height()
        if (srcW <= 0 || srcH <= 0) throw IllegalArgumentException("GIF has no size")

        // Single-frame GIFs report a duration of 0.
        val gifDurationMs = if (movie.duration() > 0) movie.duration() else DEFAULT_SINGLE_FRAME_MS
        val durationMs = minOf(gifDurationMs, MAX_DURATION_MS)

        val scale = LONGEST_SIDE.toFloat() / max(srcW, srcH).toFloat()
        val outW = evenAtLeast2((srcW * scale).toInt())
        val outH = evenAtLeast2((srcH * scale).toInt())
        val totalFrames = max(1, ((durationMs.toLong() * fps) / 1000L).toInt())

        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val pixels = IntArray(outW * outH)

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )
            setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var trackIndex = -1
        try {
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            val mux = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            val info = MediaCodec.BufferInfo()

            // Drains whatever the encoder has ready. When `untilEos` is true it blocks until EOS.
            fun drain(untilEos: Boolean) {
                var idleTries = 0
                while (true) {
                    val index = enc.dequeueOutputBuffer(info, if (untilEos) TIMEOUT_US else 0L)
                    when {
                        index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!untilEos) return
                            // ~10 s without any output while waiting for EOS: the encoder is stuck.
                            if (++idleTries > 1000) throw IllegalStateException("Encoder timed out")
                        }

                        index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Output format changed twice" }
                            trackIndex = mux.addTrack(enc.outputFormat)
                            mux.start()
                            muxerStarted = true
                        }

                        index >= 0 -> {
                            val data = enc.getOutputBuffer(index)
                                ?: throw IllegalStateException("Missing encoder output buffer")
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                                info.size = 0
                            }
                            if (info.size > 0) {
                                check(muxerStarted) { "Muxer not started" }
                                data.position(info.offset)
                                data.limit(info.offset + info.size)
                                mux.writeSampleData(trackIndex, data, info)
                            }
                            enc.releaseOutputBuffer(index, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                        }
                    }
                }
            }

            for (frame in 0 until totalFrames) {
                val timeMs = ((frame.toLong() * 1000L) / fps).toInt()
                movie.setTime(timeMs % max(1, gifDurationMs))

                bitmap.eraseColor(Color.BLACK)
                canvas.save()
                canvas.scale(outW.toFloat() / srcW, outH.toFloat() / srcH)
                movie.draw(canvas, 0f, 0f)
                canvas.restore()
                bitmap.getPixels(pixels, 0, outW, 0, 0, outW, outH)

                var inputIndex = enc.dequeueInputBuffer(TIMEOUT_US)
                while (inputIndex < 0) {
                    drain(false)
                    inputIndex = enc.dequeueInputBuffer(TIMEOUT_US)
                }
                val image = enc.getInputImage(inputIndex)
                    ?: throw IllegalStateException("Encoder does not expose an input image")
                fillImage(image, pixels, outW, outH)
                val ptsUs = (frame.toLong() * 1_000_000L) / fps
                enc.queueInputBuffer(inputIndex, 0, outW * outH * 3 / 2, ptsUs, 0)
                drain(false)
            }

            var eosIndex = enc.dequeueInputBuffer(TIMEOUT_US)
            while (eosIndex < 0) {
                drain(false)
                eosIndex = enc.dequeueInputBuffer(TIMEOUT_US)
            }
            enc.queueInputBuffer(
                eosIndex, 0, 0, (totalFrames.toLong() * 1_000_000L) / fps,
                MediaCodec.BUFFER_FLAG_END_OF_STREAM
            )
            drain(true)
        } finally {
            try {
                encoder?.stop()
            } catch (_: Exception) {
            }
            encoder?.release()
            try {
                if (muxerStarted) muxer?.stop()
            } catch (_: Exception) {
            }
            muxer?.release()
            bitmap.recycle()
        }
    }

    private fun evenAtLeast2(v: Int): Int {
        val even = if (v % 2 == 1) v - 1 else v
        return max(2, even)
    }

    /** Writes ARGB pixels into a YUV_420_888 image (BT.601, limited range). */
    private fun fillImage(image: android.media.Image, argb: IntArray, w: Int, h: Int) {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuf = yPlane.buffer
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer

        for (y in 0 until h) {
            val rowBase = y * yPlane.rowStride
            val pxBase = y * w
            for (x in 0 until w) {
                val c = argb[pxBase + x]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val yy = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yBuf.put(rowBase + x * yPlane.pixelStride, yy.coerceIn(0, 255).toByte())
            }
        }

        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                var rs = 0
                var gs = 0
                var bs = 0
                for (dy in 0..1) {
                    for (dx in 0..1) {
                        val c = argb[(y * 2 + dy) * w + (x * 2 + dx)]
                        rs += (c shr 16) and 0xFF
                        gs += (c shr 8) and 0xFF
                        bs += c and 0xFF
                    }
                }
                val r = rs / 4
                val g = gs / 4
                val b = bs / 4
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                uBuf.put(y * uPlane.rowStride + x * uPlane.pixelStride, u.coerceIn(0, 255).toByte())
                vBuf.put(y * vPlane.rowStride + x * vPlane.pixelStride, v.coerceIn(0, 255).toByte())
            }
        }
    }
}
